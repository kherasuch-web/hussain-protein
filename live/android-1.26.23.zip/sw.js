// v1.26 Windows live update: serves newer app files (downloaded by app.js) over the built-in ones.
// If a new version does not start properly twice, it goes back to the previous one by itself.
let meta = null, metaAt = 0;
async function getMeta() {
  if (meta && Date.now() - metaAt < 3000) return meta;
  try { const r = await (await caches.open("hp-live-meta")).match("/__meta"); meta = r ? await r.json() : {} } catch (e) { meta = {} }
  metaAt = Date.now(); return meta;
}
async function putMeta(o) { meta = o; metaAt = Date.now(); const c = await caches.open("hp-live-meta"); await c.put("/__meta", new Response(JSON.stringify(o), { headers: { "Content-Type": "application/json" } })) }
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin || u.pathname === "/sw.js") return;
  e.respondWith((async () => {
    let m = await getMeta();
    if (m.ver && e.request.mode === "navigate" && /\/(index\.html)?$/.test(u.pathname)) {
      if (m.pending) {                                   // new version on trial
        if ((m.tries || 0) >= 2) { m = { ver: m.prev || null, pending: false, tries: 0, bad: [...(m.bad || []), m.ver].slice(-5) }; await putMeta(m) } // go back
        else { m.tries = (m.tries || 0) + 1; await putMeta(m) }
      }
    }
    if (m.ver) {
      const hit = await (await caches.open("hp-live-v-" + m.ver)).match(new Request(u.pathname === "/" ? "/index.html" : u.pathname));
      if (hit) return hit;
    }
    return fetch(e.request);
  })());
});
